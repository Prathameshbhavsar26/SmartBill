import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import db from "./src/config/db.js";

dotenv.config();

const app = express();

app.use(cors());
app.use(express.json());

app.get("/", (req, res) => {
  res.send("SmartBill Backend Running");
});

app.get("/api/health", async (req, res) => {
  try {
    const connection = await db.getConnection();
    connection.release();

    res.json({
      status: "ok",
      database: "MySQL Connected",
    });
  } catch (err) {
    res.status(500).json({
      status: "error",
      error: err.message,
    });
  }
});

const PORT = process.env.PORT || 4000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
