# Smart Bill Backend API

Complete REST API backend for the Smart Bill Business Management Dashboard.

## Tech Stack

- **Runtime**: Node.js (ES Modules)
- **Framework**: Express.js
- **Database**: SQLite (via better-sqlite3)
- **Auth**: JWT (jsonwebtoken) + bcrypt
- **Validation**: Custom middleware

## Getting Started

### 1. Install Dependencies

```bash
cd server
npm install
```

### 2. Configure Environment

The `.env` file is already set up with defaults. Edit if needed:

```env
PORT=5000
JWT_SECRET=your_jwt_secret_key_change_in_production
JWT_EXPIRES_IN=7d
DB_PATH=./database.db
```

### 3. Seed the Database

This populates the database with demo data:

```bash
npm run seed
```

### 4. Start the Server

```bash
npm run dev
```

Server will start at: **http://localhost:5000**

## Test Accounts

After seeding, you can login with these accounts:

| Role           | Email                       | Password     |
| -------------- | --------------------------- | ------------ |
| Super Admin    | admin@smartbill.com         | Password@123 |
| Business Owner | vikram@sharmaelectronics.in | Password@123 |
| Cashier        | arjun@business.in           | Password@123 |
| Manager        | priya@business.in           | Password@123 |
| Accountant     | kavita@business.in          | Password@123 |

## API Endpoints

### Auth

| Method | Endpoint             | Description                   |
| ------ | -------------------- | ----------------------------- |
| POST   | `/api/auth/register` | Register new business + owner |
| POST   | `/api/auth/login`    | Login, returns JWT token      |
| GET    | `/api/auth/me`       | Get current user profile      |
| PUT    | `/api/auth/profile`  | Update user profile           |

### Dashboard

| Method | Endpoint                    | Description                              |
| ------ | --------------------------- | ---------------------------------------- |
| GET    | `/api/dashboard/business`   | Business owner dashboard (stats, charts) |
| GET    | `/api/dashboard/superadmin` | Super admin dashboard                    |

### Commerce

| Method         | Endpoint                  | Description                    |
| -------------- | ------------------------- | ------------------------------ |
| GET/POST       | `/api/customers`          | List / Create customers        |
| GET/PUT/DELETE | `/api/customers/:id`      | Get / Update / Delete customer |
| GET/POST       | `/api/suppliers`          | List / Create suppliers        |
| GET/PUT/DELETE | `/api/suppliers/:id`      | Get / Update / Delete supplier |
| GET/POST       | `/api/products`           | List / Create products         |
| GET            | `/api/products/low-stock` | Get low stock products         |
| GET/PUT/DELETE | `/api/products/:id`       | Get / Update / Delete product  |
| GET/POST       | `/api/categories`         | List / Create categories       |
| DELETE         | `/api/categories/:id`     | Delete category                |

### Transactions

| Method         | Endpoint                   | Description                   |
| -------------- | -------------------------- | ----------------------------- |
| GET/POST       | `/api/invoices`            | List / Create invoices        |
| GET            | `/api/invoices/:id`        | Get invoice with items        |
| PUT            | `/api/invoices/:id/status` | Update invoice status         |
| GET/POST       | `/api/purchases`           | List / Create purchases       |
| GET            | `/api/purchases/:id`       | Get purchase with items       |
| GET/POST       | `/api/expenses`            | List / Create expenses        |
| GET            | `/api/expenses/summary`    | Expense summary stats         |
| GET/PUT/DELETE | `/api/expenses/:id`        | Get / Update / Delete expense |

### Users & Notifications

| Method         | Endpoint                      | Description                    |
| -------------- | ----------------------------- | ------------------------------ |
| GET/POST       | `/api/users`                  | List / Add employees           |
| GET/PUT/DELETE | `/api/users/:id`              | Get / Update / Delete employee |
| GET            | `/api/notifications`          | List notifications             |
| PUT            | `/api/notifications/:id/read` | Mark notification as read      |
| PUT            | `/api/notifications/read-all` | Mark all as read               |

### Reports

| Method | Endpoint                   | Description                     |
| ------ | -------------------------- | ------------------------------- |
| GET    | `/api/reports/sales`       | Sales report (with date filter) |
| GET    | `/api/reports/purchase`    | Purchase report                 |
| GET    | `/api/reports/profit-loss` | Profit & Loss statement         |
| GET    | `/api/reports/gst`         | GST report                      |
| GET    | `/api/reports/inventory`   | Inventory report                |

### Super Admin

| Method         | Endpoint              | Description         |
| -------------- | --------------------- | ------------------- |
| GET            | `/api/businesses`     | List all businesses |
| GET/PUT/DELETE | `/api/businesses/:id` | Manage business     |

### Health

| Method | Endpoint      | Description         |
| ------ | ------------- | ------------------- |
| GET    | `/api/health` | Server health check |

## Authentication

All protected routes require a JWT token in the `Authorization` header:

```
Authorization: Bearer <your_jwt_token>
```

To get a token, call `POST /api/auth/login` with email and password.

## Data Flow

```
Frontend (React)
    │
    ├── Login → POST /api/auth/login → JWT Token stored in localStorage
    │
    └── All API calls → Headers: { Authorization: Bearer <token> }
            │
            ▼
    Express Server → Auth Middleware (verify JWT)
            │
            ▼
    Route Handler → SQLite Database
            │
            ▼
    JSON Response ← Frontend updates state
```

## Database

SQLite database file: `server/database.db` (auto-created)

Key tables:

- `businesses` - Multi-tenant businesses
- `users` - Users with role-based access
- `customers` / `suppliers` - Business contacts
- `products` - Inventory items with stock levels
- `invoices` / `invoice_items` - Sales transactions
- `purchases` / `purchase_items` - Purchase orders
- `expenses` - Business expenses
- `notifications` - System alerts
- `sales_data` / `daily_sales` - Chart data
