import { config } from 'dotenv';
config();

import db from './src/config/db.js';
import { initializeDatabase } from './src/models/schema.js';
import { hashPassword } from './src/utils/helpers.js';

async function seed() {
  console.log('[SEED] Starting database seed...');

  // Initialize schema first
  initializeDatabase();

  // Clear existing data
  const tables = [
    'invoice_items', 'invoices', 'purchase_items', 'purchases',
    'expenses', 'notifications', 'products', 'suppliers',
    'customers', 'categories', 'users', 'businesses',
    'sales_data', 'daily_sales',
  ];

  for (const table of tables) {
    db.prepare(`DELETE FROM ${table}`).run();
  }

  console.log('[SEED] Cleared existing data.');

  // ─── SEED BUSINESSES ──────────────────────────────────────────────────────

  const insertBiz = db.prepare(`
    INSERT INTO businesses (id, name, owner_name, owner_email, owner_phone, owner_city, plan, status, revenue, joined_date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const businesses = [
    [1, 'Sharma Electronics', 'Vikram Sharma', 'vikram@sharmaelectronics.in', '+91 8830164600', 'Nashik', 'Pro', 'Active', 245000, '2024-03-15'],
    [2, 'Mumbai Textiles', 'Nirmala Patel', 'nirmala@mumbaitextiles.in', '+91 9765969840', 'Mumbai', 'Enterprise', 'Active', 1280000, '2024-01-22'],
    [3, 'Delhi Grocers', 'Amar Singh', 'amar@delhigrocers.in', '+91 9922334455', 'Delhi', 'Starter', 'Active', 89000, '2024-06-08'],
    [4, 'Pune Hardware Hub', 'Sanjay More', 'sanjay@punehardware.in', '+91 9988776655', 'Pune', 'Pro', 'Suspended', 412000, '2024-02-14'],
    [5, 'Chennai Pharma', 'Lakshmi Rajan', 'lakshmi@chennai-pharma.in', '+91 8899001122', 'Chennai', 'Enterprise', 'Active', 2100000, '2023-11-30'],
  ];
  for (const b of businesses) {
    insertBiz.run(...b);
  }
  console.log(`[SEED] Inserted ${businesses.length} businesses.`);

  // ─── SEED USERS (with hashed passwords) ──────────────────────────────────

  const passwordHash = await hashPassword('Password@123');
  const insertUser = db.prepare(`
    INSERT INTO users (business_id, name, email, password_hash, role, phone, department, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);

  const users = [
    [null, 'System Admin', 'admin@smartbill.com', passwordHash, 'superadmin', '+91 9876543210', 'IT', 'Active'],
    [1, 'Vikram Sharma', 'vikram@sharmaelectronics.in', passwordHash, 'owner', '+91 8830164600', 'Management', 'Active'],
    [1, 'Priya Sharma', 'priya@business.in', passwordHash, 'manager', '+91 8830164601', 'Operations', 'Active'],
    [1, 'Arjun Nair', 'arjun@business.in', passwordHash, 'cashier', '+91 8830164602', 'Sales', 'Active'],
    [1, 'Kavita Reddy', 'kavita@business.in', passwordHash, 'accountant', '+91 8830164603', 'Finance', 'Active'],
    [2, 'Nirmala Patel', 'nirmala@mumbaitextiles.in', passwordHash, 'owner', '+91 9765969840', 'Management', 'Active'],
    [3, 'Amar Singh', 'amar@delhigrocers.in', passwordHash, 'owner', '+91 9922334455', 'Management', 'Active'],
    [4, 'Sanjay More', 'sanjay@punehardware.in', passwordHash, 'owner', '+91 9988776655', 'Management', 'Active'],
    [5, 'Lakshmi Rajan', 'lakshmi@chennai-pharma.in', passwordHash, 'owner', '+91 8899001122', 'Management', 'Active'],
  ];
  for (const u of users) {
    insertUser.run(...u);
  }
  console.log(`[SEED] Inserted ${users.length} users.`);

  // ─── SEED CATEGORIES ─────────────────────────────────────────────────────

  const insertCat = db.prepare('INSERT INTO categories (business_id, name) VALUES (?, ?)');
  const categories = ['Electronics', 'Clothing', 'Groceries', 'Hardware'];
  for (const bizId of [1, 2, 3, 4, 5]) {
    for (const cat of categories) {
      insertCat.run(bizId, cat);
    }
  }
  console.log('[SEED] Inserted categories.');

  // ─── SEED CUSTOMERS ──────────────────────────────────────────────────────

  const insertCust = db.prepare(`
    INSERT INTO customers (business_id, name, contact, phone, email, city, balance, invoices_count, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const customers = [
    [1, 'Raj Enterprises', 'Rajesh', '+91 8830164610', 'rajesh@raj.in', 'Mumbai', 45200, 24, 'Active'],
    [1, 'Gawali Traders', 'Omkar', '+91 8830164611', 'omkar@gawali.in', 'Nashik', 8400, 18, 'Active'],
    [1, 'Akshata Industries', 'Akshata', '+91 8830164612', 'akshata@industries.in', 'Nashik', 12800, 7, 'Inactive'],
    [1, 'Diksha Traders', 'Diksha', '+91 8830164613', 'diksha@traders.in', 'Jalgaon', -10000, 31, 'Active'],
    [1, 'Sanchit Wholesale', 'Sanchit', '+91 8830164614', 'sanchit@wholesale.in', 'Nashik', 67500, 42, 'Active'],
    [1, 'Nandini Distributors', 'Nandini', '+91 8830164615', 'nandini@distributors.in', 'Jalgaon', -2100, 15, 'Active'],
  ];
  for (const c of customers) {
    insertCust.run(...c);
  }
  console.log(`[SEED] Inserted ${customers.length} customers.`);

  // ─── SEED SUPPLIERS ──────────────────────────────────────────────────────

  const insertSupp = db.prepare(`
    INSERT INTO suppliers (business_id, name, contact, phone, email, city, balance, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const suppliers = [
    [1, 'TechVision Pvt Ltd', 'Prathamesh', '+91 9765969840', 'prathamesh@techvision.in', 'Nashik', 125000, 'Active'],
    [1, 'FabWorld Exports', 'Omkar', '+91 9765969841', 'omkar@fabworld.in', 'Dubai Phata', 43000, 'Active'],
    [1, 'AgriLink Wholesale', 'Sanchit', '+91 9765969842', 'sanchit@agrilink.in', 'Pune', 8900, 'Active'],
    [1, 'Metro Hardware Hub', 'Akshata', '+91 9765969843', 'akshata@metrohardware.in', 'Hyderabad', 31200, 'Inactive'],
  ];
  for (const s of suppliers) {
    insertSupp.run(...s);
  }
  console.log(`[SEED] Inserted ${suppliers.length} suppliers.`);

  // ─── SEED PRODUCTS ───────────────────────────────────────────────────────

  const insertProd = db.prepare(`
    INSERT INTO products (business_id, name, sku, category_name, supplier_name, cost_price, selling_price, stock, min_stock, status)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const products = [
    [1, 'Boult Audio Airbus', 'EL-SGB-001', 'Electronics', 'TechVision Pvt Ltd', 4200, 6999, 48, 10, 'Active'],
    [1, 'Max Fashion Shirt (L)', 'CL-CLS-002', 'Clothing', 'FabWorld Exports', 350, 899, 134, 20, 'Active'],
    [1, 'Basmati Rice Premium 5kg', 'GR-BR5-003', 'Groceries', 'AgriLink Wholesale', 320, 520, 8, 25, 'Active'],
    [1, 'Zeronics Mouse', 'HW-PDB-004', 'Hardware', 'Metro Hardware Hub', 2800, 4499, 22, 5, 'Active'],
    [1, 'Wireless Keyboard', 'EL-WMK-005', 'Electronics', 'TechVision Pvt Ltd', 1800, 3299, 0, 8, 'Inactive'],
    [1, 'Denim Jeans (32)', 'CL-DJS-006', 'Clothing', 'FabWorld Exports', 650, 1499, 76, 15, 'Active'],
    [1, 'Olive Oil 1L', 'GR-OOE-007', 'Groceries', 'AgriLink Wholesale', 280, 450, 61, 30, 'Active'],
  ];
  for (const p of products) {
    insertProd.run(...p);
  }
  console.log(`[SEED] Inserted ${products.length} products.`);

  // ─── SEED INVOICES ───────────────────────────────────────────────────────

  const insertInv = db.prepare(`
    INSERT INTO invoices (business_id, invoice_no, customer_id, customer_name, subtotal, gst, total, status, date)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  const invoices = [
    [1, 'INV-2024-1042', 1, 'Raj Enterprises', 28750, 5175, 33925, 'Paid', '2024-08-14'],
    [1, 'INV-2024-1041', 2, 'Mehta Traders', 12400, 2232, 14632, 'Pending', '2024-08-13'],
    [1, 'INV-2024-1040', 3, 'Gupta Wholesale', 67800, 12204, 80004, 'Paid', '2024-08-12'],
    [1, 'INV-2024-1039', 4, 'Sharma & Sons', 5600, 1008, 6608, 'Overdue', '2024-08-11'],
    [1, 'INV-2024-1038', 5, 'Singh Distributors', 19200, 3456, 22656, 'Paid', '2024-08-10'],
  ];
  for (const inv of invoices) {
    insertInv.run(...inv);
  }
  console.log(`[SEED] Inserted ${invoices.length} invoices.`);

  // ─── SEED EXPENSES ───────────────────────────────────────────────────────

  const insertExp = db.prepare(`
    INSERT INTO expenses (business_id, category, description, amount, date, payment_mode, status)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const expenses = [
    [1, 'Rent', 'Office & Warehouse Rent - August', 45000, '2024-08-01', 'Bank Transfer', 'Paid'],
    [1, 'Utilities', 'Electricity & Internet Bills', 8200, '2024-08-05', 'UPI', 'Paid'],
    [1, 'Salaries', 'Staff Salaries - August', 125000, '2024-08-07', 'Bank Transfer', 'Paid'],
    [1, 'Marketing', 'Google Ads Campaign', 15000, '2024-08-10', 'Credit Card', 'Paid'],
    [1, 'Logistics', 'Delivery & Transport Costs', 12400, '2024-08-12', 'Cash', 'Pending'],
  ];
  for (const e of expenses) {
    insertExp.run(...e);
  }
  console.log(`[SEED] Inserted ${expenses.length} expenses.`);

  // ─── SEED NOTIFICATIONS ──────────────────────────────────────────────────

  const insertNotif = db.prepare(`
    INSERT INTO notifications (business_id, type, title, message, is_read)
    VALUES (?, ?, ?, ?, ?)
  `);
  const notifications = [
    [1, 'warning', 'Low Stock Alert', 'Basmati Rice Premium 5kg has only 8 units remaining (Min: 25)', 0],
    [1, 'error', 'Payment Overdue', 'Invoice INV-2024-1039 from Sharma & Sons is overdue by 3 days', 0],
    [1, 'success', 'Payment Received', '₹33,925 received from Raj Enterprises for INV-2024-1042', 1],
    [1, 'info', 'System Update', 'Smart Bill v1.0.0 is ready with new features', 1],
    [1, 'warning', 'Low Stock Alert', 'Wireless Keyboard is out of stock', 1],
  ];
  for (const n of notifications) {
    insertNotif.run(...n);
  }
  console.log(`[SEED] Inserted ${notifications.length} notifications.`);

  // ─── SEED SALES DATA (charts) ────────────────────────────────────────────

  const insertSalesData = db.prepare(`
    INSERT INTO sales_data (business_id, month, sales, purchases, profit, year)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const salesData = [
    [1, 'Jan', 145000, 89000, 56000, 2024],
    [1, 'Feb', 178000, 102000, 76000, 2024],
    [1, 'Mar', 162000, 95000, 67000, 2024],
    [1, 'Apr', 210000, 118000, 92000, 2024],
    [1, 'May', 195000, 110000, 85000, 2024],
    [1, 'Jun', 248000, 135000, 113000, 2024],
    [1, 'Jul', 231000, 128000, 103000, 2024],
    [1, 'Aug', 267000, 142000, 125000, 2024],
  ];
  for (const d of salesData) {
    insertSalesData.run(...d);
  }
  console.log(`[SEED] Inserted ${salesData.length} sales data records.`);

  // ─── SEED DAILY SALES ────────────────────────────────────────────────────

  const insertDailySales = db.prepare(`
    INSERT INTO daily_sales (business_id, day, amount)
    VALUES (?, ?, ?)
  `);
  const dailySales = [
    [1, 'Mon', 18400],
    [1, 'Tue', 22100],
    [1, 'Wed', 19800],
    [1, 'Thu', 25600],
    [1, 'Fri', 31200],
    [1, 'Sat', 28900],
    [1, 'Sun', 15400],
  ];
  for (const d of dailySales) {
    insertDailySales.run(...d);
  }
  console.log(`[SEED] Inserted ${dailySales.length} daily sales records.`);

  console.log(`
╔══════════════════════════════════════════════════╗
║           Seed Completed Successfully!           ║
║──────────────────────────────────────────────────║
║  Test Accounts:                                  ║
║  ─────────────────                               ║
║  Admin:   admin@smartbill.com                    ║
║  Owner:   vikram@sharmaelectronics.in            ║
║  Cashier: arjun@business.in                      ║
║  Password for ALL: Password@123                  ║
╚══════════════════════════════════════════════════╝
  `);

  process.exit(0);
}

seed().catch(err => {
  console.error('[SEED] Error:', err);
  process.exit(1);
});

